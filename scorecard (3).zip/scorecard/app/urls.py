from django import views
from django.urls import path
from . import views

urlpatterns = [
    path('',views.login_user, name='login'),
    path('login',views.login_user, name='login'),
    # path('signup',views.signup, name='signuppage'),
    path('app_form',views.application_form, name = 'app_form'),
    path('overall',views.overall, name='overall'),
    path('home2',views.home, name='home2'),
    path('gauge', views.charts, name = 'gauge'),
]