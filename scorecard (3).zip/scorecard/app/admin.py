from django.contrib import admin
from .models import applicationScore

# Register your models here.
admin.site.register(applicationScore)